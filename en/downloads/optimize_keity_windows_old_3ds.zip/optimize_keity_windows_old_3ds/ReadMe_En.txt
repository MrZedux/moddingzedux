=============================================================================
	Three line differential signal viewer for ChameleonUSB SPA3A kit

	n3DS_view.exe  (multi Pair Signal Video viewer)
	Copyright (c) non-standard.com / tanishige

=============================================================================
 [About this software]

This software provides 3DS LCD signals on the monitor of Windows PCs, using the Camereon USB SPA 3A. 

=============================================================================
 [Operation environment]

OS: Windows XP, Vista 7, and above.
Conditions:
	- DirectX9 and above.
	- The device driver for the EZ-USB FX2 by Cypress will work correctly if you use the 64 bits OS. 
	- Needs a suitable environment for the stable transfer of data through USB2.0.

=============================================================================
[Warning and indemnity] 

We accept no responsibility whatsoever for any damages resulting from the use of this software. Please use this software at your own risk.

This software is for the purpose of temporarily providing digital signals for LCD units to your PC monitor, as a streaming video. If you record the displayed video using this software and/or distribute it on the Internet, you may be in conflict with the Copyright Act.

We do not have a schedule to upgrade the product, including upgrades to encryption or copy protection.

The hardware specification in terms of electrical signal in an operating environment is specified according to our standards. With regards to this software, please do not address inquiries to the hardware manufactures.  

Games implemented by the SPA3A kit can be considered as a remodelling radio if the acquisition of the "Giteki" mark is applied to the entire game airframe, not to the built-in Wi-Fi module. In this case, you need to turn off the Wi-Fi feature or acquire the "Giteki" mark again. Non-standard.com cannot give you any advice on or support for this matter. Please use this software at your own risk.

=============================================================================
[About this software]

n3DS_view.exe is software attached to a special hardware product. This software is not freeware, so please do not copy or redistribute this software.

You need the product key attached to the hardware product at startup. The product key will be verified with the individual ID built into the Camereon USB SPA3A. If you use multiple products, you need to input the product key on each product.  

=============================================================================
 [About USB connection]

This software needs sufficient stable transfer speed.

It is preferable to use this software connected through a root hub that has no other USB connected to it. Using the Windows device manager, you can check the number of root hubs and their connections. 

If your PC has an available USB3.0 port, you can use the port for this software.

=============================================================================
[Production and copyright]

The copyright of n3DS_view belongs to TANISHIGE (S.Tani.).
Copying of the programs or documents of n3DS_view without prior consent is prohibited. 

=============================================================================
* Microsoft Windows is the trademark of Microsoft.
